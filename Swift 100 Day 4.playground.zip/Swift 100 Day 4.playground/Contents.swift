import Cocoa

//How to use type annotations

let surname: String = "Lasso"
var score: Int = 0

var albums: [String] = ["Red", "Fearless"]
var user: [String: String] = ["id": "@twostraws"]
var teams: [String] = [String]()

enum UIStyle {
    case light, dark, system
}

var style = UIStyle.light
style = .dark

//Checkpoint 2

let checkpoint2 = ["Strings", "Arrays", "Sets", "enum", "Strings"]

print(checkpoint2.count)
let checkpoint2Set = Set(checkpoint2)
print(checkpoint2Set.count)



