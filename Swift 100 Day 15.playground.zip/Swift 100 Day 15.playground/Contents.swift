import Cocoa

//Review day!

var name = "Ted"
name = "Rebecca"

let user = "Daphne"
print(user)

let actor = "Tom Cruise 😎"

let quote = "He tapped a sign saying\"Beleive\" and walked away"

let movie = """
A day in the life of an
Apple engineer
"""

print(actor.count)
print(quote.hasSuffix("Away"))

let score = 10
let higherScore = score + 10
let halvedScore = score / 2

var counter = 10
counter += 5

let number = 120
print(number.isMultiple(of: 3))

let id = Int.random(in: 1...1000)

name = "Taylor"
let age = 26
let message = "I'm \(name) and I'm \(age) years old."

let employee = [
    "name": "Taylor"
]

var numbers = Set([1,5,6,7,11,5])
print(numbers)

numbers.insert(10)
numbers.contains(11)

enum Weekday {
    case monday, tuesday, wednesday, thursday, friday
}

var day = Weekday.friday

var scores: Double = 0

let player: String = "Roy"
var albums: Array<String> = ["Red", "Fearless"]
var users: [String: String] = ["id": "@twostraws"] //This is a dictionary

if age < 12 {
    print("You can't vote.")
} else if age < 18 {
    print("You can vote soon.")
} else {
    print("You can vote now!")
}

enum Weather {
    case sun, rain, wind
}

let forecast = Weather.sun

switch forecast {
case .sun:
    print("A nice day")
case .rain:
    print("Pack an umbrella.")
default:
    print("Should be okay.")
}

let canVote = age >= 18 ? "Yes" : "No"
print(canVote)

let platforms  = ["ios", "macos", "tvos"]

for os in platforms {
    print("Swift works on \(os)")
}

for i in 1..<12 {
    print("5 x \(i) is \(5 * i)")
}

func printTimesTables(number: Int) {
    for i in 1...12 {
        print("\(i) x \(number) is \(i * number)")
    }
}

printTimesTables(number: 8)

func isUppercase(_ string: String) -> Bool {
    string == string.uppercased()
}

let string = "HELLO WORLD"
let res = isUppercase(string)
















