import Cocoa

//How to reuse code with functions

func showWelcome() {
print("Welcome to my app!")
print("By default This prints out a conversation")
print("chart from centimeters to inches, but you")
print("can also set a custom range if you want.")
}

showWelcome()

let number = 139

if number.isMultiple(of: 2) {
    print("Even")
} else {
    print("Odd")
}

let roll = Int.random(in: 1...20)

func printTimesTables(number: Int, end: Int) {
    for i in 1...end {
        print("\(i) * \(number) is \(i * number)")
    }
}

printTimesTables(number: 5, end: 20)

//How to return values from functions

let root = sqrt(169)
print(root)

//func rollDice() -> Int {
//    Int.random(in: 1...6)
//}

//let result = rollDice()
//print(result)

func palendrome(firstString: String, secondString: String) -> Bool {
    firstString.sorted() == secondString.sorted()
}

func pythgoras(a: Double, b: Double) -> Double {
    sqrt(a * a + b * b)
}

let c = pythgoras(a: 3, b: 4)
print(c)

func sayHello() {
    return
}

//How to return multiple values from functions

func isUppercase(string: String) -> Bool {
    string == string.uppercased()
}

//This is a tuple

func getUser() -> (firstName: String, lastName: String) {
    ("Taylor", "Swift")
}

let user = getUser()
print("Name: \(user.firstName) \(user.lastName)")

//How to extract info from a tuple

let (firstName, lastName) = getUser()
print("Name: \(firstName) \(lastName)")

//How to customize parameters lables

func rollDice(sides: Int, count: Int) -> [Int] {
    var rolls = [Int]()
    
    for _ in 1...count {
        let roll = Int.random(in: 1...sides)
        rolls.append(roll)
    }
    
    return rolls
}
    

let rolls = rollDice(sides: 6, count: 4)

func hireEmployee(name: String) {}
func hireEmployee(title: String) {}
func hireEmployee(location: String) {}

let lyric = "I see a red door and I want to paint it black."
print(lyric.hasPrefix("I see"))

func isUppercase(_ string: String) -> Bool {
    string == string.uppercased()
}

let string = "HELLO WORLD"
let result = isUppercase(string)

func printTimesTable(for number: Int) {
    for i in 1...12 {
        print("\(i) x \(number) is \(i * number)")
    }
}

printTimesTable(for: 5)


